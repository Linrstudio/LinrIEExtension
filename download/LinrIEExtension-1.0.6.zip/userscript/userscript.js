//�����û��ű�
//if(document.getElementById('ires')){
var links = document.getElementById('ires').getElementsByTagName('a');

// add target _blank and remove event handler
for(var i = 0, j = links.length; i<j; i++){
    links[i].setAttribute('target', '_blank');  // depends on your need
    links[i].removeAttribute('onmousedown');
    links[i].style.color='red';
}
}