var bookmarklets = [
	{
		name : "QRCode",
		image : "images/qrcode.png",
		source : '(function(d,e){e=d.createElement("div");e.innerHTML=\'<img src="https://chart.googleapis.com/chart?cht=qr&chs=200x200&choe=UTF-8&chld=L|4&chl=\'+d.URL+\'">\';e.style.cssText="position:fixed;z-index:99999;_position:absolute;right:10px;top:10px;background:#FFF;border:10px solid #FFF;width:200px;height:200px;box-shadow:1px 1px 3px #CCC";d.body.appendChild(e);})(document);'
	},
	{
		name : "Firebug",
		image : "images/firebug.png",
		source : '(function(F,i,r,e,b,u,g,L,I,T,E){if(F.getElementById(b))return;E=F[i+"NS"]&&F.documentElement.namespaceURI;E=E?F[i+"NS"](E,"script"):F[i]("script");E[r]("id",b);E[r]("src",I+g+T);E[r](b,u);(F[e]("head")[0]||F[e]("body")[0]).appendChild(E);E=new Image;E[r]("src",I+L);})(document,"createElement","setAttribute","getElementsByTagName","FirebugLite","4","firebug-lite.js","releases/lite/latest/skin/xp/sprite.png","https://getfirebug.com/","#startOpened");'
	},
	{
		name : "翻译",
		image : "images/ctf.png",
		source : 'location.href="http://www.microsofttranslator.com/bv.aspx?from=&to=zh-CHS&a=" + encodeURIComponent(location.href); void(0);'
	},
	{
		name : "Bing翻译",
		image : "images/ctf.png",
		source : '(function(){var s = document.createElement("script"); s.type = "text/javascript"; s.src = "http://labs.microsofttranslator.com/bookmarklet/default.aspx?f=js&to=zh-chs"; document.body.insertBefore(s, document.body.firstChild);})()'
	},
	{
		name : "QQ输入法",
		image : "images/ime.png",
		source : '(function(q){q?q.toggle():function(d,j){j=d.createElement("script");j.async=true;j.src="//ime.qq.com/fcgi-bin/getjs";j.setAttribute("ime-cfg","lt=2");d=d.getElementsByTagName("head")[0];d.insertBefore(j,d.firstChild)}(document)})(window.QQWebIME)'
	},
	{
		name : "Aardvark",
		image : "images/ardvark.png",
		source : 'document.getElementsByTagName("head")[0].appendChild(document.createElement("script")).setAttribute("src","http://www.karmatics.com/aardvark/bookmarklet.js");void 0;'
	},
	{
		name : "FLV获取/下载",
		image : "images/flvcd.png",
		source : 'location.href="http://www.flvcd.com/parse.php?kw="+encodeURIComponent(location.href);'
	},
	{
		name : "获取页面Flash地址",
		image : "images/flash.png",
		source : '(function(d,a,f,g){g=" style=color:#00ABDC";a=d.querySelectorAll?d.querySelectorAll("object,embed"):d.getElementsByTagName("object");f=d.createElement("div");f.style.cssText="position:absolute;z-index:99999;right:5px;top:5px;padding:5px;background:#FFF;border:1px solid #EEE;border-radius:3px;box-shadow:1px 1px 3px #CCC;";for(var i=0,j=a.length,c;i<j;i++){c=a[i];f.innerHTML=(c.data ? "<div><a href="+c.data+g+">"+c.data+" 右键另存为</a></div>" : "") + (c.movie ? "<div><a href="+c.movie+g+">"+c.movie+" 右键另存为</a></div>":"") + (c.src ? "<div><a href="+c.src+g+">"+c.src+" 右键另存为</a></div>":"");d.body.appendChild(f);}})(document);'
	},
	{
		name : "Readability",
		image : "images/Readability.png",
		source : '((function(){window.baseUrl="http://www.readability.com";window.readabilityToken="";var s=document.createElement("script");s.setAttribute("type","text/javascript");s.setAttribute("charset","UTF-8");s.setAttribute("src",baseUrl+"/bookmarklet/read.js");document.documentElement.appendChild(s);})());'
	},
	{
		name : "Mobile perf",
		image : "images/mobileperf.png",
		source : '(function(){var%20jselem=document.createElement("SCRIPT");jselem.type="text/javascript";jselem.src="http://stevesouders.com/mobileperf/mobileperfbkm.js";document.getElementsByTagName("body")[0].appendChild(jselem);})();'
	},
	{
		name : "右键解禁",
		image : "images/contextmenu.png",
		source : '(function(){document.body.oncontextmenu="return%20true";document.body.ondragstart="return%20true";document.body.onselectstart="return%20true";document.body.onbeforecopy="return%20true";})();'
	},
	{
		name : "编辑模式",
		image : "images/edit.png",
		source : '(function(){document.body.contentEditable=true;document.execCommand("2D-Position",false,true);})();'
	}
];
/* http://plod.popoever.com/archives/000526.html */